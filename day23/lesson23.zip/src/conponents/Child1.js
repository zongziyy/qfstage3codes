import React from 'react'
import  Child2 from  "./Child2";

export default function Child1() {
    return (
        <div>
            父组件
            <Child2></Child2>
        </div>
    )
}
