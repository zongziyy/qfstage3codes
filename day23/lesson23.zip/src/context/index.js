import  react from "react";
let  numInfo ={
    value:10
}
export default  react.createContext(numInfo);
