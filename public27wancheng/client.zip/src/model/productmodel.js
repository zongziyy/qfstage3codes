import  axios from  "./axios.js";
import  qs  from  "qs";

var  productmodelInfo = {
    add(info){
        return  axios({
            method:"post",
            url:"/api/productmodel/add",
            data:qs.stringify(info)
        })
    },
    list(){
        return  axios({
            method:"get",
            url:"/api/productmodel/list"
        })
    }
}


export default  productmodelInfo;