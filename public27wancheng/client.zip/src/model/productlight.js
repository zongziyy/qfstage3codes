import  axios from  "./axios.js";
import  qs  from  "qs";

var  productlightInfo = {
    add(info){
        return  axios({
            method:"post",
            url:"/api/productlight/add",
            data:qs.stringify(info)
        })
    },
    list(){
        return  axios({
            method:"get",
            url:"/api/productlight/list"
        })
    }
}


export default  productlightInfo;