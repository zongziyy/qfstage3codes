import  axios from  "./axios.js";
import  qs  from  "qs";

var  productInfo = {
    add(info){
        return  axios({
            method:"post",
            url:"/api/product/add",
            data:qs.stringify(info)
        })
    },
    list(){
        return  axios({
            method:"get",
            url:"/api/product/list"
        })
    }
}


export default  productInfo;