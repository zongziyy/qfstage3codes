import  axios from  "./axios.js";
import  qs  from  "qs";

var  productdirectionInfo = {
    add(info){
        return  axios({
            method:"post",
            url:"/api/productdirection/add",
            data:qs.stringify(info)
        })
    },
    list(){
        return  axios({
            method:"get",
            url:"/api/productdirection/list"
        })
    }
}


export default  productdirectionInfo;