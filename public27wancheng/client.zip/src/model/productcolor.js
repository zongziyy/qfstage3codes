import  axios from  "./axios.js";
import  qs  from  "qs";

var  productcolorInfo = {
    add(info){
        return  axios({
            method:"post",
            url:"/api/productcolor/add",
            data:qs.stringify(info)
        })
    },
    list(){
        return  axios({
            method:"get",
            url:"/api/productcolor/list"
        })
    }
}


export default  productcolorInfo;