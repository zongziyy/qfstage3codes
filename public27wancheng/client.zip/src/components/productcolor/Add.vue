<template>
  <div>
    <el-button type="primary" @click="dialogFormVisible = true"
      >新增产品颜色</el-button
    >
    <el-dialog title="产品颜色" :visible.sync="dialogFormVisible">
      <el-form
        :model="ruleForm"
        status-icon
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="产品颜色" prop="productcolor">
          <el-input type="text" v-model="ruleForm.productcolor"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submitForm('ruleForm')"
            >提交</el-button
          >
          <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import productcolorinfo from "../../model/productcolor";
import { mapMutations } from "vuex";
export default {
  data() {
    return {
      dialogFormVisible: false,
      ruleForm: {
        productcolor: ""
      },
      rules: {
        productname: [
          { required: true, message: "产品颜色不能为空", trigger: "blur" },
          {
            pattern: /^.{1,50}$/i,
            message: "长度1到50位",
            trigger: "blur"
          }
        ]
    }
    };
  },
  methods: {
    ...mapMutations(["addProductcolorItem"]),
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          var info = {
            productcolor: this.ruleForm.productcolor
          };
          productcolorinfo.add(info).then(result => {
            if (result.data.code == 1) {
              this.$refs[formName].resetFields();
              this.dialogFormVisible = false;
              this.addProductcolorItem(info);
            } else {
              this.$message.error(result.data.msg);
            }
          });
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
      this.dialogFormVisible = false;
    }
  }
};
</script>