<template>
  <div>
    <el-button type="primary" @click="dialogFormVisible = true"
      >新增产品型号</el-button
    >
    <el-dialog title="产品型号" :visible.sync="dialogFormVisible">
      <el-form
        :model="ruleForm"
        status-icon
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <el-form-item label="产品型号" prop="productmodel">
          <el-input type="text" v-model="ruleForm.productmodel"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submitForm('ruleForm')"
            >提交</el-button
          >
          <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script>
import productmodelinfo from "../../model/productmodel";
import { mapMutations } from "vuex";
export default {
  data() {
    return {
      dialogFormVisible: false,
      ruleForm: {
        productmodel: ""
      },
      rules: {
        productmodel: [
          { required: true, message: "产品型号不能为空", trigger: "blur" },
          {
            pattern: /^.{1,50}$/i,
            message: "长度1到50位",
            trigger: "blur"
          }
        ]
    }
    };
  },
  methods: {
    ...mapMutations(["addProductmodelItem"]),
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          var info = {
            productmodel: this.ruleForm.productmodel
          };
          productmodelinfo.add(info).then(result => {
            if (result.data.code == 1) {
              this.$refs[formName].resetFields();
              this.dialogFormVisible = false;
              this.addProductmodelItem(info);
            } else {
              this.$message.error(result.data.msg);
            }
          });
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
      this.dialogFormVisible = false;
    }
  }
};
</script>