<template>
  <div>
    <el-button
      type="primary"
      @click="dialogFormVisible = true"
      style="float:left"
      >新增订货单</el-button
    >
    <el-dialog title="新增订货单" :visible.sync="dialogFormVisible">
      <el-form
        :model="ruleForm"
        status-icon
        :rules="rules"
        ref="ruleForm"
        label-width="120px"
        class="demo-ruleForm"
      >
        <el-form-item label="产品名称" prop="productname">
          <!-- <el-input type="text" v-model="ruleForm.productname"></el-input>
       -->
          <el-select
            v-model="ruleForm.productname"
            filterable
            placeholder="请选择"
            @change="changeProductname()"
          >
            <el-option
              v-for="item in productnameList"
              :key="item._id"
              :label="item.productname"
              :value="item.productname"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="产品型号" prop="productmodel">
          <el-input type="text" v-model="ruleForm.productmodel"></el-input>
          <!-- <el-select
            v-model="ruleForm.productmodel"
            filterable
            placeholder="请选择"
          >
            <el-option
              v-for="item in productmodelList"
              :key="item._id"
              :label="item.productmodel"
              :value="item.productmodel"
            >
            </el-option>
          </el-select> -->
        </el-form-item>
        <el-form-item label="表面处理(颜色)" prop="productcolor">
          <!-- <el-input type="text" v-model="ruleForm.productcolor"></el-input> -->
          <el-select
            v-model="ruleForm.productcolor"
            filterable
            placeholder="请选择"
          >
            <el-option
              v-for="item in productcolorList"
              :key="item._id"
              :label="item.productcolor"
              :value="item.productcolor"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="光源" prop="productlight">
          <!-- <el-input type="text" v-model="ruleForm.productlight"></el-input> -->
          <el-select
            v-model="ruleForm.productlight"
            filterable
            placeholder="请选择"
          >
            <el-option
              v-for="item in productlightList"
              :key="item._id"
              :label="item.productlight"
              :value="item.productlight"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="出线方向" prop="productdirection">
          <!-- <el-input type="text" v-model="ruleForm.productdirection"></el-input> -->
          <el-select
            v-model="ruleForm.productdirection"
            filterable
            placeholder="请选择"
          >
            <el-option
              v-for="item in productdirectionList"
              :key="item._id"
              :label="item.productdirection"
              :value="item.productdirection"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="规格(mm)" prop="productsize">
          <el-input type="text" v-model="ruleForm.productsize"></el-input>
        </el-form-item>
        <el-form-item label="数量(支)" prop="productnum">
          <el-input type="text" v-model="ruleForm.productnum"></el-input>
        </el-form-item>
        <el-form-item label="单价(元/米)" prop="productprice">
          <el-input type="text" v-model="ruleForm.productprice"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submitForm('ruleForm')"
            >提交</el-button
          >
          <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<style scoped>
>>>.el-input .el-input__inner{
  width: 50%;
}
>>>.el-input--suffix .el-input__inner{
  width: 100%;
}
</style>
<script>
import order from "../../model/order";
import product from "../../model/product";
import productcolor from "../../model/productcolor";
import productdirection from "../../model/productdirection";
import productlight from "../../model/productlight";
import productmodel from "../../model/productmodel";

import { mapState, mapMutations } from "vuex";
export default {
  props: ["orderid","neworderid"],
  data() {
    return {
      dialogFormVisible: false,
      productnameList: [],
      productmodelList: [],
      productcolorList: [],
      productlightList: [],
      productdirectionList: [],
      ruleForm: {
        productname: "",
        productmodel: "",
        productcolor: "",
        productlight: "", //光源
        productdirection: "", //方向
        productsize: "", //规格(mm)
        productnum: "", //数量
        productprice: "" //产品价格
      },
      rules: {
        partaname: [
          { required: true, message: "产品名称不能为空", trigger: "blur" }
        ],
        productmodel: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        productcolor: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        productlight: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        productdirection: [
          { required: true, message: "不能为空", trigger: "blur" }
        ],
        productsize: [{ required: true, message: "不能为空", trigger: "blur" }],
        productnum: [{ required: true, message: "不能为空", trigger: "blur" }],
        productprice: [{ required: true, message: "不能为空", trigger: "blur" }]
      }
    };
  },
  mounted() {
    product.list().then(result => {
      this.productnameList = result.data.msg;
    });
    productcolor.list().then(result => {
      this.productcolorList = result.data.msg;
    });
    productdirection.list().then(result => {
      this.productdirectionList = result.data.msg;
    });
    productmodel.list().then(result => {
      this.productmodelList = result.data.msg;
    });
    productlight.list().then(result => {
      this.productlightList = result.data.msg;
    });
   
  },
  computed: {
    ...mapState(["partainfo", "partbinfo", "orderList"])
  },
  methods: {
    ...mapMutations(["addOrderItem"]),
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          
          if (this.neworderid!=0||(this.partainfo.partaid && this.partbinfo.partbid)) {
            var info = {
              orderid: this.orderid,
              partaid: this.partainfo.partaid,
              partbid: this.partbinfo.partbid,
              productname: this.ruleForm.productname,
              productmodel: this.ruleForm.productmodel,
              productcolor: this.ruleForm.productcolor,
              productlight: this.ruleForm.productlight,
              productdirection: this.ruleForm.productdirection,
              productsize: this.ruleForm.productsize,
              productnum: this.ruleForm.productnum,
              productprice: this.ruleForm.productprice
            };
            order.add(info).then(result => {
              if (result.data.code == 1) {
                this.$refs[formName].resetFields();
                this.dialogFormVisible = false;
                this.addOrderItem({ ...info, id: this.orderList.length + 1 });
              } else {
                this.$message.error(result.data.msg);
              }
            });
          }
        } else {
          this.$message.error("请从选择甲方开始");
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
      this.dialogFormVisible = false;
    },
    changeProductname() {
      // console.log(  this.productnameList.filter(item=>item.productname==this.ruleForm.productname)[0])
      // console.log(this.productnameList)

      var  productList  = this.productnameList.filter(item=>item.productname==this.ruleForm.productname);
      if(productList.length){
         this.ruleForm.productmodel = productList[0].productmodel;
      }

    }
  }
};
</script>