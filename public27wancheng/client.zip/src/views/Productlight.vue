<template>
  <div>
    <productlight-add></productlight-add>
    <div>
      <el-table :data="productlightList" border style="width: 100%">
        <el-table-column fixed prop="productlight" label="光源">
        </el-table-column>
        <el-table-column label="状态">
          <template>
            <el-button type="warning" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import add from "../components/productlight/Add";
import productlightInfo from "../model/productlight";
import {mapState,mapMutations} from "vuex";
export default {
  data() {
    return {
      
    };
  },
  computed:{
    ...mapState(["productlightList"])
  },
  methods:{
    ...mapMutations(["initProductlightList"])
  },
  mounted() {
   productlightInfo.list().then(result => {
      this.initProductlightList(result.data.msg);
    });
  },
  components: {
    "productlight-add": add
  }
};
</script>