<template>
  <div>
    <product-add></product-add>
    <div>
      <el-table :data="productList" border style="width: 100%">
        <el-table-column fixed prop="productname" label="产品名称">
        </el-table-column>
         <el-table-column fixed prop="productmodel" label="产品型号">
        </el-table-column>
        <el-table-column label="状态">
          <template>
            <el-button type="warning" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import add from "../components/product/Add";
import productInfo from "../model/product";
import {mapState,mapMutations} from "vuex";
export default {
  data() {
    return {
      
    };
  },
  computed:{
    ...mapState(["productList"])
  },
  methods:{
    ...mapMutations(["initProductList"])
  },
  mounted() {
    productInfo.list().then(result => {
      this.initProductList(result.data.msg);
    });
  },
  components: {
    "product-add": add
  }
};
</script>