<template>
  <div>
    <productcolor-add></productcolor-add>
    <div>
      <el-table :data="productcolorList" border style="width: 100%">
        <el-table-column fixed prop="productcolor" label="颜色">
        </el-table-column>
        <el-table-column label="状态">
          <template>
            <el-button type="warning" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import add from "../components/productcolor/Add";
import productcolorInfo from "../model/productcolor";
import {mapState,mapMutations} from "vuex";
export default {
  data() {
    return {
      
    };
  },
  computed:{
    ...mapState(["productcolorList"])
  },
  methods:{
    ...mapMutations(["initProductcolorList"])
  },
  mounted() {
    productcolorInfo.list().then(result => {
      this.initProductcolorList(result.data.msg);
    });
  },
  components: {
    "productcolor-add": add
  }
};
</script>