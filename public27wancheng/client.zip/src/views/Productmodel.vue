<template>
  <div>
    <productmodel-add></productmodel-add>
    <div>
      <el-table :data="productmodelList" border style="width: 100%">
        <el-table-column fixed prop="productmodel" label="光源">
        </el-table-column>
        <el-table-column label="状态">
          <template>
            <el-button type="warning" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import add from "../components/productmodel/Add";
import productmodelInfo from "../model/productmodel";
import {mapState,mapMutations} from "vuex";
export default {
  data() {
    return {
      
    };
  },
  computed:{
    ...mapState(["productmodelList"])
  },
  methods:{
    ...mapMutations(["initProductmodelList"])
  },
  mounted() {
   productmodelInfo.list().then(result => {
      this.initProductmodelList(result.data.msg);
    });
  },
  components: {
    "productmodel-add": add
  }
};
</script>