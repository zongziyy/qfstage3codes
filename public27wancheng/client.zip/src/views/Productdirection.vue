<template>
  <div>
    <productdirection-add></productdirection-add>
    <div>
      <el-table :data="productdirectionList" border style="width: 100%">
        <el-table-column fixed prop="productdirection" label="出口方向">
        </el-table-column>
        <el-table-column label="状态">
          <template>
            <el-button type="warning" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import add from "../components/productdirection/Add";
import productdirectionInfo from "../model/productdirection";
import {mapState,mapMutations} from "vuex";
export default {
  data() {
    return {
      
    };
  },
  computed:{
    ...mapState(["productdirectionList"])
  },
  methods:{
    ...mapMutations(["initProductdirectionList"])
  },
  mounted() {
   productdirectionInfo.list().then(result => {
      this.initProductdirectionList(result.data.msg);
    });
  },
  components: {
    "productdirection-add": add
  }
};
</script>