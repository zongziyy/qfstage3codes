<template>
  <div>
    <el-table
      :data="orderList"
      border
      style="width: 100%"
    >
      <el-table-column prop="orderid" label="订单编号" > 
          <template slot-scope="scope">
            <span @click="gotoDetail(scope.row.orderid)"> {{scope.row.orderid}}</span>
        </template>

      </el-table-column>
      <el-table-column prop="partaid.partaname" label="甲方名称">
      </el-table-column>
      <el-table-column prop="productname" label="产品名称"> </el-table-column>
        <el-table-column prop="productmodel" label="产品型号"> </el-table-column>
      <el-table-column prop="productcolor" label="表面处理(颜色)">
      </el-table-column>
      <el-table-column prop="productlight" label="光源"> </el-table-column>
      <el-table-column prop="productdirection" label="出线方向">
      </el-table-column>
      <el-table-column prop="productsize" label="规格(mm)"> </el-table-column>
      <el-table-column prop="productnum" label="数量(支)"> </el-table-column>
      <el-table-column prop="productprice" label="单价(元/米)">
      </el-table-column>
      <el-table-column prop="producttotal" label="金额(元)">
        <template slot-scope="scope">
          <span v-if="scope.row.productsize > 500">
            {{
              (
                (scope.row.productnum *
                  scope.row.productprice *
                  scope.row.productsize) /
                1000
              ).toFixed(2)
            }}
          </span>
          <span v-else>
            {{
              (scope.row.productnum * scope.row.productprice * 0.5).toFixed(2)
            }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="状态">
        <template>
          <el-button type="warning" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
import orderinfo from "../model/order";
export default {
  data() {
    return {
      orderList: [],
    };
  },
  mounted() {
    this.getList()
  },
  methods: {
    //根据订单编号获取数据
    async getList() {
      await orderinfo.list().then(result => {
        this.orderList = result.data.list;
      });
    },
    gotoDetail(orderid){
        this.$router.push({
            name:"order",
            params:{
                orderid:orderid
            }

        })
    }
  }
};
</script>
  