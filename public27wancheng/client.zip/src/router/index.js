import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home
  },
  {
    path: "/print/:orderid",
    name: "print",
    component: () =>
      import("../views/Print.vue")
  },
  {
    path: "/menu",
    name: "menu",
    component: () => import("../views/Menu.vue"),

    children: [{
      path: "parta",
      name: "parta",
      component: () =>
        import("../views/Parta.vue")
    },
    {
      path: "partb",
      name: "partb",
      component: () =>
        import("../views/Partb.vue")
    },
    {
      path: "order",
      name: "order",
      component: () =>
        import("../views/Order.vue")
    },
    {
      path: "product",
      name: "product",
      component: () =>
        import("../views/Product.vue")
    },
    {
      path: "productcolor",
      name: "productcolor",
      component: () =>
        import("../views/Productcolor.vue")
    },{
      path: "productdirection",
      name: "productdirection",
      component: () =>
        import("../views/Productdirection.vue")
    },
    {
      path: "productlight",
      name: "productlight",
      component: () =>
        import("../views/Productlight.vue")
    },
    {
      path: "productmodel",
      name: "productmodel",
      component: () =>
        import("../views/Productmodel.vue")
    },
    {
      path: "orderlist",
      name: "orderlist",
      component: () =>
        import("../views/Orderlist.vue")
    },
    ]
  }
];

const router = new VueRouter({
  routes
});

export default router;
