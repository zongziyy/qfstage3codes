let productlightModel = require("./productlightTable");

let productlightInfo = {
    add: (info) => {
        return productlightModel.insertMany([info])
    },
    list: () => {
        return productlightModel.find();
    }
}
module.exports= productlightInfo;
