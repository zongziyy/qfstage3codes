let productModel = require("./productmodelTable");

let productModelInfo = {
    add: (info) => {
        return productModel.insertMany([info])
    },
    list: () => {
        return productModel.find();
    }
}
module.exports=productModelInfo;
