let productcolorModel = require("./productcolorTable");

let productcolorInfo = {
    add: (info) => {
        return productcolorModel.insertMany([info])
    },
    list: () => {
        return productcolorModel.find();
    }
}
module.exports=productcolorInfo;
