let productModel = require("./productTable");

let productInfo = {
    add: (info) => {
        return productModel.insertMany([info])
    },
    list: () => {
        return productModel.find();
    }
}
module.exports =productInfo;
