var mongoose = require("../db.js");
var schema = mongoose.Schema; //模型生成器(表生成器)

//建立表 并且指定字段
var productSchema = new schema({
    productname:String,//名称
    productmodel:String,//型号
});
//转成数据模型导出
module.exports = mongoose.model("product", productSchema);