let productdirectionModel = require("./productdirectionTable");

let productdirectionInfo = {
    add: (info) => {
        return productdirectionModel.insertMany([info])
    },
    list: () => {
        return productdirectionModel.find();
    }
}
module.exports= productdirectionInfo;
