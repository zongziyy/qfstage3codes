var mongoose = require("../db.js");
var schema = mongoose.Schema; //模型生成器(表生成器)

//建立表 并且指定字段
var productdirectionSchema = new schema({
    productdirection:String,//名称
});
//转成数据模型导出
module.exports = mongoose.model("productdirectionInfo", productdirectionSchema);