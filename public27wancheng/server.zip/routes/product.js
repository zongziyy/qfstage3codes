const { json } = require('express');
var express = require('express');
var router = express.Router();
var productInfo = require("../model/product");

/* GET home page. */
router.get('/list', function(req, res, next) {
    productInfo.list().then(result=>{
        res.json({
            code:1,
            msg:result
        })
    })
});
router.post("/add",(req,res,next)=>{
    // partaname:String,//名称
    // tel:String,//电话
    // date:Date,//日期
    let  {productname,productmodel}= req.body;
    productInfo.add({productname,productmodel}).then((result)=>{
        if(result.length){
            res.json({
                code:1,
                msg:"成功"
            })
        }
    })
})

module.exports = router;
